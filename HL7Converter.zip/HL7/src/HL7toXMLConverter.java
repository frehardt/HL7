import ca.uhn.hl7v2.parser.*;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.v24.message.DFT_P03;

public class HL7toXMLConverter {
    
    public static void main(String args[]) {
        //for demo purposes, we just declare a literal message string 
        String ackMessageString 
          //  = "MSH|^~\\&|foo|foo||foo|200108151718||ACK^A01^ACK|1|D|2.4|\rMSA|AA\r";
        = "MSH|^~\\&|LABVANTAGE||LABVANTAGE|ILINK|20150204170905||DFT^P03|31955268|P|2.3|\r" +
"EVN|P03|20150204001056|\r" +
"PID|1||12676276||^|||U|\r" +
"PV1|1|C|^^^^^^^^STUA||||||||||||||||\r" +
"FT1|1|36||20150203142700|20150203142806|CG|70.7000.00|01||1|||LABV0000000000000036|^||^^^^^^^^LBSL|\r" +
"FT1|1|37||20150203142700|20150203142806|CG|70.7001.07|01||4|||LABV0000000000000037|^||^^^^^^^^LBSL|\r" +
"FT1|1|38||20150203142700|20150203142806|CG|70.7018.07|01||4|||LABV0000000000000038|^||^^^^^^^^LBSL|\r" +
"FT1|1|39||20150203142700|20150203142806|CG|70.7002.07|01||4|||LABV0000000000000039|^||^^^^^^^^LBSL|\r" +
"FT1|1|40||20150203142700|20150203142806|CG|70.7003.07|01||4|||LABV0000000000000040|^||^^^^^^^^LBSL|";
        
        //instantiate a PipeParser, which handles the "traditional encoding" 
        PipeParser pipeParser = new PipeParser();
        
        try {
            //parse the message string into a Message object 
            Message message = pipeParser.parse(ackMessageString);
            
            //if it is an ACK message (as we know it is),  cast it to an 
            // ACK object so that it is easier to work with, and change a value            
            if (message instanceof ca.uhn.hl7v2.model.v24.message.DFT_P03) {
            	ca.uhn.hl7v2.model.v24.message.DFT_P03 ack = (ca.uhn.hl7v2.model.v24.message.DFT_P03) message;
                ack.getMSH().getProcessingID().getProcessingMode().setValue("P");
            }
            
            //instantiate an XML parser 
            XMLParser xmlParser = new DefaultXMLParser();
            
            //encode message in XML 
            String ackMessageInXML = xmlParser.encode(message);
            
            //print XML-encoded message to standard out
            System.out.println(ackMessageInXML);
        } catch (Exception e) {
            e.printStackTrace();
        }       
    }
}

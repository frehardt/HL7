import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.parser.DefaultXMLParser;
import ca.uhn.hl7v2.parser.PipeParser;

/**
 * 
 * @author Florian Refardt IT Logix AG
 * @version 1.0
 * @since 22.04.2016
 * @category This class is a convenience converter that reads a xml file, parses
 *           it and writes it to a destination folder
 *
 */

public class XMLtoHL7converter {

	public XMLtoHL7converter() {
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * 
	 * @param args, args[0] holds the path to the xml file, args[1] holds the xml file name, args[2] holds the hl7 file target path, args[3] holds the hl7 file name
	 * @throws HL7Exception
	 *
	 */
	public static void main(String[] args) throws HL7Exception {

		String xmlPath = args[0];
		String xmlFileName = args[1];
		String hl7Path = args[2];
		String hl7FileName = args[3];

		try {

			String xmlFile = readFile(xmlPath + xmlFileName, StandardCharsets.UTF_8);
			DefaultXMLParser XParser = new DefaultXMLParser();
			PipeParser classicParser = new PipeParser();
			String hl7Message = null;

			int indexOfNamespace = xmlFile.indexOf("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");

			xmlFile = new StringBuilder(xmlFile).insert(indexOfNamespace, "xmlns=\"urn:hl7-org:v2xml\" ").toString();

			try {

				Message msg;

				msg = XParser.parse(xmlFile);
				hl7Message = classicParser.encode(msg);

				FileWriter writeHL7ToFile = new FileWriter(
						File.createTempFile(hl7FileName, ".hl7", new File(hl7Path)));
				writeHL7ToFile.write(hl7Message);
				writeHL7ToFile.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	static String readFile(String path, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}

}
